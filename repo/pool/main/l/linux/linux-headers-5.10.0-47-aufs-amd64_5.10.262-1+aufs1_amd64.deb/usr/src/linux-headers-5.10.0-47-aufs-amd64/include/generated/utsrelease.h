#define UTS_RELEASE "5.10.0-47-aufs-amd64"
