#define LINUX_PACKAGE_ID " Debian 6.12.116-1+aufs1"
