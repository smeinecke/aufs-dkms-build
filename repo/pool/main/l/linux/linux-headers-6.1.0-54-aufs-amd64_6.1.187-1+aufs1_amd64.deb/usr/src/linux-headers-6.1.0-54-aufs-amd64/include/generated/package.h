#define LINUX_PACKAGE_ID " Debian 6.1.187-1+aufs1"
