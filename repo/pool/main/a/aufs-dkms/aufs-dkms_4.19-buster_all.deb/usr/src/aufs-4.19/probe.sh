#!/bin/sh
# Emit -D flags describing the VFS API of the target kernel headers.
# $1 = kernel build dir (e.g. /lib/modules/VERSION/build). Debian keeps
# the -common headers in a sibling dir reachable via the "source" link.

kdir="$1"

hdr() {
	for d in "${kdir}" "$(dirname "${kdir}")/source"; do
		f="$(readlink -f "${d}")/include/linux/$1"
		[ -f "${f}" ] && { cat "${f}"; return; }
	done
}

hdr fs.h     | grep -qw 'setfl'          || printf ' %s' '-DAUFS_NO_FOP_SETFL'
hdr splice.h | grep -qw 'do_splice_from' || printf ' %s' '-DAUFS_NO_DO_SPLICE_FROM'
hdr fs.h     | grep -q 'vfs_rename(struct renamedata' && printf ' %s' '-DAUFS_RENAME_DATA'

# aufs needs kernel-internal symbols that are only exported when the
# kernel is built with aufs-standalone.patch (as in Debian buster's
# kernel); fail with a readable message instead of modpost errors
symvers="${kdir}/Module.symvers"
[ -f "${symvers}" ] || symvers="$(readlink -f "$(dirname "${kdir}")/source")/Module.symvers"
if [ -f "${symvers}" ]; then
	missing=""
	for s in vfs_read vfs_write d_walk d_exchange do_truncate path_noexec \
	    security_path_chmod security_path_rmdir security_path_symlink \
	    security_file_permission; do
		awk -v s="${s}" '$2 == s && $4 ~ /^EXPORT_SYMBOL/ {f=1} END {exit !f}' \
		    "${symvers}" || missing="${missing} ${s}"
	done
	if [ -n "${missing}" ]; then
		echo >&2 "probe.sh: target kernel does not export:${missing}"
		echo >&2 "probe.sh: a kernel built with aufs-standalone.patch is required"
		printf ' %s' '-DAUFS_MISSING_EXPORTS'
	fi
fi
echo
